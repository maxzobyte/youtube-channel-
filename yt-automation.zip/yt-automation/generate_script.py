"""
Generates daily video scripts about 21st century business topics using Gemini API.
Produces two scripts: a long-form (5-10 min) and a short-form (<60s).
Output: script_long.json and script_short.json with structured scenes for video assembly.
"""

import os
import json
import re
import requests

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"


def call_gemini(prompt, max_tokens=2048):
    """Call Gemini API with a text prompt and return the text response."""
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.9,
            "maxOutputTokens": max_tokens,
        }
    }
    resp = requests.post(GEMINI_URL, json=payload, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    return data["candidates"][0]["content"]["parts"][0]["text"]


def extract_json(text):
    """Extract a JSON object/array from model output, stripping markdown fences."""
    text = text.strip()
    # Remove markdown code fences if present
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return json.loads(text)


LONG_PROMPT = """You are a scriptwriter for a faceless YouTube channel about "Business in the 21st Century" \
(topics: startups, business models, AI's impact on work, future of business, entrepreneurship, modern economy, \
remote work, digital marketing, e-commerce, finance trends).

Pick ONE specific, interesting topic within this niche (different each time, be creative — avoid generic \
"what is a startup" type topics, go specific e.g. "Why subscription businesses are taking over" or \
"The rise of solopreneurs powered by AI").

Write a video script for a 6-9 minute narrated explainer video. The script must be broken into 10-16 segments. \
Each segment should be a self-contained chunk of narration (2-4 sentences, conversational, engaging, no fluff), \
plus 2-4 short keywords describing what image should appear on screen during that segment (keywords should be \
simple, concrete, searchable terms like "office team meeting", "stock market chart", "laptop coding", etc — \
think of what a stock photo site would have), plus a short on-screen text overlay (3-8 words, punchy, \
Notion-style key phrase summarizing the segment's main point).

Return ONLY a valid JSON object with this exact structure, no markdown, no commentary:

{
  "title": "Catchy YouTube title (60-70 chars, include a hook)",
  "description": "YouTube description, 2-3 sentences summarizing the video plus a call to action to subscribe",
  "tags": ["tag1", "tag2", "tag3", "... 10-15 relevant SEO tags"],
  "segments": [
    {
      "narration": "Text to be spoken for this segment.",
      "image_keywords": ["keyword1", "keyword2"],
      "overlay_text": "Short Punchy Phrase"
    }
  ]
}
"""

SHORT_PROMPT = """You are a scriptwriter for a faceless YouTube Shorts channel about "Business in the 21st Century".

Write a script for a vertical YouTube Short (45-58 seconds when narrated). It should be a punchy, hook-driven \
piece of content: a surprising fact, a quick tip, or a fast take on a modern business trend. Strong hook in the \
first segment to stop scrolling.

Break it into 5-8 short segments. Each segment: 1-2 sentences of narration (punchy, fast-paced, conversational), \
2-3 image keywords (simple searchable stock photo terms), and a short on-screen text overlay (2-6 words, bold).

Return ONLY a valid JSON object with this exact structure, no markdown, no commentary:

{
  "title": "Catchy YouTube Shorts title (under 60 chars, include relevant hook/emoji optional)",
  "description": "Short description, 1-2 sentences plus #Shorts hashtag and a call to action to subscribe",
  "tags": ["tag1", "tag2", "... 8-12 relevant SEO tags including 'Shorts'"],
  "segments": [
    {
      "narration": "Text to be spoken for this segment.",
      "image_keywords": ["keyword1", "keyword2"],
      "overlay_text": "Short Phrase"
    }
  ]
}
"""


def main():
    print("Generating long-form script...")
    long_text = call_gemini(LONG_PROMPT, max_tokens=4096)
    long_script = extract_json(long_text)
    with open("script_long.json", "w") as f:
        json.dump(long_script, f, indent=2)
    print(f"Long script: '{long_script['title']}' ({len(long_script['segments'])} segments)")

    print("Generating short-form script...")
    short_text = call_gemini(SHORT_PROMPT, max_tokens=1536)
    short_script = extract_json(short_text)
    with open("script_short.json", "w") as f:
        json.dump(short_script, f, indent=2)
    print(f"Short script: '{short_script['title']}' ({len(short_script['segments'])} segments)")


if __name__ == "__main__":
    main()
